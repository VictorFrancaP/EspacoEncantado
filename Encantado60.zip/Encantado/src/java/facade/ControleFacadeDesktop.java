/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package facade;

import DAO.EncantadoDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Encantado;


public class ControleFacadeDesktop {
    
    public String acionarCadastrar(Encantado ee){
        
        EncantadoDAO eedao = new EncantadoDAO();
        String message = "";
        try {
            eedao.cadastrar(ee);
            message = "CADASTRADO COM SUCESSO";
        } catch (ClassNotFoundException | SQLException ex) {
            message = "CADASTRO NÃO REALIZADO: " + ex.getMessage();
            System.out.println("Erro: " + ex.getMessage());
        }
        return message;
    }
    
     public Encantado acionarConsultarByID(Encantado enc) {
 
        EncantadoDAO eedao = new EncantadoDAO();
        String message = "";
        Encantado ee = new Encantado();
        
        try {
            ee = eedao.consultarById(enc);
            message = "CONSULTAR REALIZADO COM SUCESSO";
        } catch (ClassNotFoundException | SQLException ex) {
            message = "CONSULTAR NÃO REALIZADO: " + ex.getMessage(); 
            System.out.println("Erro: " + ex.getMessage());
        }
 
        return ee;
 
    }
     
     public String acionarDeletar(Encantado ee){
        
       EncantadoDAO eedao = new EncantadoDAO();
       String message = "";
        
        try {
            eedao.excluir(ee);
            message = "DELETADO COM SUCESSO";
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Erro: " + ex.getMessage());
        }
        return message;
    }
     
     public String acionarAtualizar(Encantado ee) {
        EncantadoDAO eedao = new EncantadoDAO();
        String message = "";
        try {
            eedao.atualizar(ee);
            message = "ATUALIZAÇÃO REALIZADA";
        } catch (ClassNotFoundException | SQLException ex) {
            message = "CONSULTAR NÃO REALIZADO: " + ex.getMessage();
            System.out.println("Erro: " + ex.getMessage());
 
        }
 
        return message;
    }
     
     public String acionarEfetAtualizacao(Encantado ee){
        
        EncantadoDAO eedao = new EncantadoDAO();
        String message = "";
        try {
            eedao.cadastrar(ee);
            message = "ATUALIZADO COM SUCESSO";
        } catch (ClassNotFoundException | SQLException ex) {
            message = "ATUALIZAÇÃO NÃO REALIZADA: " + ex.getMessage();
            System.out.println("Erro: " + ex.getMessage());
        }
        return message;
    }
    
      
      
    
}
