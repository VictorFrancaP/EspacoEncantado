
package ppoo_decorator;


public class PPOO_Decorator {

   
    public static void main(String[] args) {
     

        INotifier notifyMail = new Notifier("encantado");
        notifyMail.send("Festa agendada");
        
        System.out.println("==========================================");

        INotifier notifyAll = new FacebookDecorator(new WhatsAppDecorator(new TelegramDecorator(new Notifier("encantado"))));
        notifyAll.send("Festa agendada!!!");

        System.out.println("==========================================");

        INotifier notifyWAppMail = new WhatsAppDecorator(new Notifier("encantado"));
        notifyWAppMail.send("Festa agendada!!!");

        System.out.println("==========================================");

        INotifier notifyTgmFbMail = new TelegramDecorator(new FacebookDecorator(new Notifier("encantado")));
        notifyTgmFbMail.send("Festa agendada!!!");

    }
}
