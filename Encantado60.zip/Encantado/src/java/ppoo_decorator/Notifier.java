
package ppoo_decorator;

import ppoo_decorator.DatabaseService;
import ppoo_decorator.INotifier;


public class Notifier implements INotifier {

    private final String username;
    private final DatabaseService databaseService;

    public Notifier(String username) {
        this.username = username;
        databaseService = new DatabaseService();
    }

    @Override
    public void send(String msg) {
        String mail = databaseService.getMailFromUsername(username);
        System.out.println("Enviando... " + msg + " pelo Email para:" + mail);
    }

    @Override
    public String getUsername() {
        return username;
    }

}
