
package ppoo_decorator;


public class TelegramDecorator extends BaseNotifierDecorator {

    public TelegramDecorator(INotifier wrapped) {
        super(wrapped);
    }

    @Override
    public void send(String msg) {
        super.send(msg);
        String phoneNbr = databaseService.getPhoneNbrFromUsername(getUsername());
        System.out.println("Enviando... " + msg + " pelo Telegram para: " + phoneNbr);
    }
}
