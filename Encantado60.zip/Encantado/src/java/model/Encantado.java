/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Encantado {

    private int id;
    private String nomeFesta;
    private String tema;
    private String periodo;
    private String endereco;
    private String listaConvidados;
    private String menu;
    private String atividades;
    private String decoracao;
    private String obsEspeciais;
    private String orcamento;

    public Encantado() {
        super();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomeFesta() {
        return nomeFesta;
    }

    public void setNomeFesta(String nomeFesta) {
        this.nomeFesta = nomeFesta;
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getListaConvidados() {
        return listaConvidados;
    }

    public void setListaConvidados(String listaConvidados) {
        this.listaConvidados = listaConvidados;
    }

    public String getMenu() {
        return menu;
    }

    public void setMenu(String menu) {
        this.menu = menu;
    }

    public String getAtividades() {
        return atividades;
    }

    public void setAtividades(String atividades) {
        this.atividades = atividades;
    }

    public String getDecoracao() {
        return decoracao;
    }

    public void setDecoracao(String decoracao) {
        this.decoracao = decoracao;
    }

    public String getObsEspeciais() {
        return obsEspeciais;
    }

    public void setObsEspeciais(String obsEspeciais) {
        this.obsEspeciais = obsEspeciais;
    }

    public String getOrcamento() {
        return orcamento;
    }

    public void setOrcamento(String orcamento) {
        this.orcamento = orcamento;
    }

    public static EncantadoBuilder getBuilder() {
        return new EncantadoBuilder();
    }

    public static class EncantadoBuilder {

        private Encantado ee = new Encantado();

        public EncantadoBuilder comId(int id) {
            ee.id = id;
            return this;
        }

        public EncantadoBuilder comNomeFesta(String nomeFesta) {
            ee.nomeFesta = nomeFesta;
            return this;
        }

        public EncantadoBuilder comTema(String tema) {
            ee.tema = tema;
            return this;
        }

        public EncantadoBuilder comPeriodo(String periodo) {
            ee.periodo = periodo;
            return this;
        }

        public EncantadoBuilder comEndereco(String endereco) {
            ee.endereco = endereco;
            return this;
        }

        public EncantadoBuilder comListaConvidados(String listaConvidados) {
            ee.listaConvidados = listaConvidados;
            return this;
        }

        public EncantadoBuilder comMenu(String menu) {
            ee.menu = menu;
            return this;
        }

        public EncantadoBuilder comAtividades(String atividades) {
            ee.atividades = atividades;
            return this;
        }

        public EncantadoBuilder comDecoracao(String decoracao) {
            ee.decoracao = decoracao;
            return this;
        }

        public EncantadoBuilder comObsEspeciais(String obsEspeciais) {
            ee.obsEspeciais = obsEspeciais;
            return this;
        }

        public EncantadoBuilder comOrcamento(String orcamento) {
            ee.orcamento = orcamento;
            return this;
        }

        public Encantado constroi() {
            return ee;
        }
    }
}
