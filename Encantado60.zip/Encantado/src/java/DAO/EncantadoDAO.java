/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Encantado;
import util.FabricaConexao;

/**
 *
 * @author alunos
 */
public class EncantadoDAO {
    
     public void cadastrar(Encantado encantado) throws ClassNotFoundException, SQLException {

        Connection conexao = FabricaConexao.getConexao();
        String sql = "INSERT INTO festa (nomeFesta, tema, periodo, endereco, listaConvidados, menu, atividades, decoracao, obsEspeciais, orcamento) VALUES (?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement ee = conexao.prepareStatement(sql);
        ee.setString(1, encantado.getNomeFesta());
        ee.setString(2, encantado.getTema());
        ee.setString(3, encantado.getPeriodo());
        ee.setString(4, encantado.getEndereco());
        ee.setString(5, encantado.getListaConvidados());
        ee.setString(6, encantado.getMenu());
        ee.setString(7, encantado.getAtividades());
        ee.setString(8, encantado.getDecoracao());
        ee.setString(9, encantado.getObsEspeciais());
        ee.setString(10, encantado.getOrcamento());
        ee.execute();
        conexao.close();
    }
    
    
    public void excluir(Encantado encantado) throws ClassNotFoundException, SQLException {
        Connection conexao = FabricaConexao.getConexao();
        String sql = "DELETE FROM festa where id = ?";
        PreparedStatement pstmt = conexao.prepareStatement(sql);
        pstmt.setInt(1, encantado.getId());
        pstmt.execute();
        conexao.close();
    }
    
    public void atualizar(Encantado encantado) throws ClassNotFoundException, SQLException {
        Connection conexao = FabricaConexao.getConexao();
        String sql = "UPDATE festa SET nomeFesta = ?, tema =?, periodo =?, endereco =?, listaConvidados =? , menu =?, atividades =?, decoracao =?, obsEspeciais =?, orcamento =? WHERE id=?";
        PreparedStatement pstmt = conexao.prepareStatement(sql);
        pstmt.setString(1, encantado.getNomeFesta());
        pstmt.setString(2, encantado.getTema());
        pstmt.setString(3, encantado.getPeriodo());
        pstmt.setString(4, encantado.getEndereco());
        pstmt.setString(5, encantado.getListaConvidados());
        pstmt.setString(6, encantado.getMenu());
        pstmt.setString(7, encantado.getAtividades());
        pstmt.setString(8, encantado.getDecoracao());
        pstmt.setString(9, encantado.getObsEspeciais());
        pstmt.setString(10, encantado.getOrcamento());
        pstmt.setInt(11, encantado.getId());
        pstmt.execute();
        conexao.close();
    }
    
    public Encantado consultarById(Encantado ee) throws ClassNotFoundException, SQLException {
        Connection conexao = FabricaConexao.getConexao();
        String sql = "SELECT * FROM festa WHERE id=?";
        PreparedStatement pstmt = conexao.prepareStatement(sql);
        pstmt.setInt(1, ee.getId());
        ResultSet rs = pstmt.executeQuery();
        if(rs.next()){
            ee.setId(rs.getInt("id"));
            ee.setNomeFesta(rs.getString("nomeFesta"));
            ee.setTema(rs.getString("tema"));
            ee.setPeriodo(rs.getString("periodo"));
            ee.setEndereco(rs.getString ("endereco"));
            ee.setListaConvidados(rs.getString ("listaConvidados"));
            ee.setMenu(rs.getString("menu"));
            ee.setAtividades(rs.getString("atividades"));
            ee.setDecoracao(rs.getString("decoracao"));
            ee.setObsEspeciais(rs.getString("obsEspeciais"));
            ee.setOrcamento(rs.getString("orcamento"));
            
        }else{ 
            ee=null;
        }
        conexao.close();
        return ee;
    }
        
    public List<Encantado> consultarTodos() throws ClassNotFoundException, SQLException {
        
        Connection conexao = FabricaConexao.getConexao();
        String sql = "SELECT * FROM festa";
        PreparedStatement pstmt = conexao.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        
        
        List<Encantado> lee = new ArrayList<Encantado>();
        while(rs.next()){
            
            Encantado ee = Encantado.getBuilder()
                    
            .comId(rs.getInt("id"))
            .comNomeFesta(rs.getString("nomeFesta"))
            .comTema(rs.getString("tema"))
            .comPeriodo(rs.getString("periodo"))
            .comEndereco(rs.getString ("endereco"))
            .comListaConvidados(rs.getString ("listaConvidados"))
            .comMenu(rs.getString ("menu"))
            .comAtividades(rs.getString("atividades"))
            .comDecoracao(rs.getString("decoracao"))
            .comObsEspeciais(rs.getString("obsEspeciais"))
            .comOrcamento(rs.getString("orcamento"))
            .constroi();
            
            lee.add(ee);
        }
        conexao.close();
        return lee;
    }

   
    }

    
