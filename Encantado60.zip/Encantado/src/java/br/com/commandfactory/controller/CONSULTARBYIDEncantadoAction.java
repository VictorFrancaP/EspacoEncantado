/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.commandfactory.controller;

import DAO.EncantadoDAO;
import java.sql.SQLException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Encantado;

/**
 *
 * @author PTOLEDO
 */
public class CONSULTARBYIDEncantadoAction implements ICommand {

    @Override
    public String executar(HttpServletRequest request, HttpServletResponse response) {
        String txtid = request.getParameter("txtid");
        int id = Integer.parseInt(txtid);
        EncantadoDAO eedao = new EncantadoDAO();
        
        
        
        Encantado ee = Encantado.getBuilder()
                .comId(id)
                .constroi();
        
        
        try {
            ee = eedao.consultarById(ee);
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Erro: " + ex.getMessage());
        }
        request.setAttribute("lee", ee);
        return "resultadoconsultarbyid.jsp";
    }
}
