/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.commandfactory.controller;

import DAO.EncantadoDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Encantado;

/**
 *
 * @author PTOLEDO
 */
public class CONSULTARTODOSEncantadoAction implements ICommand {

    @Override
    public String executar(HttpServletRequest request, HttpServletResponse response) {
        EncantadoDAO eedao = new EncantadoDAO();
        List<Encantado> lee = new ArrayList<Encantado>();
        try {
            lee = eedao.consultarTodos();
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Erro: " + ex.getMessage());
        }
        request.setAttribute("lee", lee);
        return "resultadoconsultartodos.jsp";
    }
}
