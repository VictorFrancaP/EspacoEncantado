/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.commandfactory.controller;

import DAO.EncantadoDAO;
import java.sql.SQLException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Encantado;

/**
 *
 * @author PTOLEDO
 */
public class CADASTRAREncantadoAction implements ICommand {

    @Override
    public String executar(HttpServletRequest request, HttpServletResponse response) {
        String nomeFesta = request.getParameter("txtnomeFesta");
                String tema = request.getParameter("txttema");
                String periodo = request.getParameter("txtperiodo");
                String endereco = request.getParameter("txtendereco");
                String listaConvidados = request.getParameter("txtlistaConvidados");
                String menu = request.getParameter("txtmenu");
                String atividades = request.getParameter("txtatividades");
                String decoracao = request.getParameter("txtdecoracao");
                String obsEspeciais = request.getParameter("txtobsEspeciais");
                String orcamento = request.getParameter("txtorcamento");
        EncantadoDAO eedao = new EncantadoDAO();
        /*
        Cliente cli = new Cliente();
        cli.setNome(nome);
        cli.setTelefone(telefone);
        cli.setEndereco(endereco);
        */
        
        Encantado ee = Encantado.getBuilder()
                .comNomeFesta(nomeFesta)
                .comTema(tema)
                .comPeriodo(periodo)
                .comEndereco(endereco)
                .comListaConvidados(listaConvidados)
                .comMenu(menu)
                .comAtividades(atividades)
                .comDecoracao(decoracao)
                .comObsEspeciais(obsEspeciais)
                .comOrcamento(orcamento)
                .constroi();
        
        
        String message = "";
        try {
            eedao.cadastrar(ee);
            
            
            
            message = "CADASTRADO COM SUCESSO";
        } catch (ClassNotFoundException | SQLException ex) {
            message = "CADASTRO NÃO REALIZADO: " + ex.getMessage();
            System.out.println("Erro: " + ex.getMessage());
        }
        request.setAttribute("message", message);
        return "resultadocadastrar.jsp";
    }
}
