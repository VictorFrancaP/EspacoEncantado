/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.commandfactory.controller;

import DAO.EncantadoDAO;
import java.sql.SQLException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Encantado;

/**
 *
 * @author PTOLEDO
 */
public class DELETAREncantadoAction implements ICommand {

    @Override
    public String executar(HttpServletRequest request, HttpServletResponse response) {
        int id = Integer.parseInt(request.getParameter("txtid"));
        EncantadoDAO eedao = new EncantadoDAO();
        
        /*
        Cliente cli = new Cliente();
        cli.setId(id);
        */
        
        Encantado ee = Encantado.getBuilder()
                .comId(id)
                .constroi();
        
        String message = "";
        try {
            eedao.excluir(ee);
            message = "EXCLUÍDO COM SUCESSO";
        } catch (ClassNotFoundException | SQLException ex) {
            message = "EXCLUSÃO NÃO REALIZADA: " + ex.getMessage();
            System.out.println("Erro: " + ex.getMessage());
        }
        request.setAttribute("message", message);
        return "resultadodeletar.jsp";
    }
}
