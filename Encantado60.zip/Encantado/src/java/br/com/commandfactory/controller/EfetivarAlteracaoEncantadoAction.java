
package br.com.commandfactory.controller;

import DAO.EncantadoDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Encantado;


public class EfetivarAlteracaoEncantadoAction implements ICommand {

    @Override
    public String executar(HttpServletRequest request, HttpServletResponse response) {
        EncantadoDAO eedao = new EncantadoDAO();
        List<Encantado> lee = new ArrayList<Encantado>();
        Encantado ee = Encantado.getBuilder()
                .comId(Integer.parseInt(request.getParameter("txtid")))
                .comNomeFesta(request.getParameter("txtnomeFesta"))
                .comTema(request.getParameter("txttema"))
                .comPeriodo(request.getParameter("txtperiodo"))
                .comEndereco(request.getParameter("txtendereco"))
                .comListaConvidados(request.getParameter("txtlistaConvidados"))
                .comMenu(request.getParameter("txtmenu"))
                .comAtividades(request.getParameter("txtatividades"))
                .comDecoracao(request.getParameter("txtdecoracao"))
                .comObsEspeciais(request.getParameter("txtobsEspeciais"))
                .comOrcamento(request.getParameter("txtorcamento"))
                .constroi();
        try {
            eedao.atualizar(ee);
            lee = eedao.consultarTodos();
        } catch (ClassNotFoundException | SQLException ex) {;
            System.out.println("Erro: " + ex.getMessage());
        }
        request.setAttribute("lee", lee);
        return "resultadoconsultartodos.jsp";
    }
}
